﻿namespace KIOS_HIS.BVHDG
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMaBN = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbTheUutien = new System.Windows.Forms.Label();
            this.btnDangKy = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbThongbao = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lbLoi = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnKhamMoi = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lbKhamMoi = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.lbCom = new System.Windows.Forms.Label();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1348, 697);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1348, 697);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1348, 697);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1348, 697);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 1047F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.lbCom, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel5, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel6, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel7, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.panel8, 1, 7);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 84F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1342, 691);
            this.tableLayoutPanel1.TabIndex = 9;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtMaBN);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(150, 175);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1041, 78);
            this.panel1.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 33F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(296, 53);
            this.label1.TabIndex = 13;
            this.label1.Text = "Mã tìm kiếm";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtMaBN
            // 
            this.txtMaBN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMaBN.Font = new System.Drawing.Font("Tahoma", 46F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaBN.Location = new System.Drawing.Point(361, 1);
            this.txtMaBN.Margin = new System.Windows.Forms.Padding(3, 10, 300, 3);
            this.txtMaBN.MaxLength = 500;
            this.txtMaBN.Name = "txtMaBN";
            this.txtMaBN.Size = new System.Drawing.Size(783, 82);
            this.txtMaBN.TabIndex = 1;
            this.txtMaBN.TextChanged += new System.EventHandler(this.txtMaBN_TextChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txtHoTen);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(150, 259);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1041, 84);
            this.panel2.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 33F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(352, 53);
            this.label2.TabIndex = 14;
            this.label2.Text = "Tên Bệnh nhân";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtHoTen
            // 
            this.txtHoTen.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtHoTen.Font = new System.Drawing.Font("Tahoma", 46F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHoTen.Location = new System.Drawing.Point(361, 1);
            this.txtHoTen.Margin = new System.Windows.Forms.Padding(3, 10, 300, 3);
            this.txtHoTen.MaxLength = 500;
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(783, 82);
            this.txtHoTen.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lbTheUutien);
            this.panel3.Controls.Add(this.btnDangKy);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(150, 349);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1041, 84);
            this.panel3.TabIndex = 16;
            // 
            // lbTheUutien
            // 
            this.lbTheUutien.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTheUutien.ForeColor = System.Drawing.Color.Green;
            this.lbTheUutien.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbTheUutien.Location = new System.Drawing.Point(68, 26);
            this.lbTheUutien.Margin = new System.Windows.Forms.Padding(3);
            this.lbTheUutien.Name = "lbTheUutien";
            this.lbTheUutien.Size = new System.Drawing.Size(222, 40);
            this.lbTheUutien.TabIndex = 5;
            this.lbTheUutien.Text = "Dùng thẻ ưu tiên!";
            this.lbTheUutien.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnDangKy
            // 
            this.btnDangKy.BackColor = System.Drawing.Color.CadetBlue;
            this.btnDangKy.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangKy.Location = new System.Drawing.Point(360, 1);
            this.btnDangKy.Name = "btnDangKy";
            this.btnDangKy.Size = new System.Drawing.Size(430, 82);
            this.btnDangKy.TabIndex = 3;
            this.btnDangKy.Text = "ĐĂNG KÝ KHÁM";
            this.btnDangKy.UseVisualStyleBackColor = false;
            this.btnDangKy.Visible = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.lbThongbao);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(150, 39);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1041, 74);
            this.panel4.TabIndex = 17;
            // 
            // lbThongbao
            // 
            this.lbThongbao.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbThongbao.Font = new System.Drawing.Font("Tahoma", 38F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbThongbao.ForeColor = System.Drawing.Color.Green;
            this.lbThongbao.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbThongbao.Location = new System.Drawing.Point(0, 0);
            this.lbThongbao.Margin = new System.Windows.Forms.Padding(300, 3, 3, 3);
            this.lbThongbao.Name = "lbThongbao";
            this.lbThongbao.Size = new System.Drawing.Size(1041, 74);
            this.lbThongbao.TabIndex = 4;
            this.lbThongbao.Text = "Vui lòng nhập/quẹt Mã BN để lấy số thứ tự";
            this.lbThongbao.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.lbLoi);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(150, 119);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1041, 50);
            this.panel5.TabIndex = 18;
            // 
            // lbLoi
            // 
            this.lbLoi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbLoi.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLoi.ForeColor = System.Drawing.Color.Red;
            this.lbLoi.Location = new System.Drawing.Point(0, 0);
            this.lbLoi.Margin = new System.Windows.Forms.Padding(0);
            this.lbLoi.Name = "lbLoi";
            this.lbLoi.Size = new System.Drawing.Size(1041, 50);
            this.lbLoi.TabIndex = 3;
            this.lbLoi.Text = "Lỗi: Nhập sai mã Bệnh nhân!";
            this.lbLoi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label3);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(150, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1041, 30);
            this.panel6.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1041, 30);
            this.label3.TabIndex = 0;
            this.label3.Text = "|";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Visible = false;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.btnKhamMoi);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(150, 543);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1041, 84);
            this.panel7.TabIndex = 20;
            // 
            // btnKhamMoi
            // 
            this.btnKhamMoi.BackColor = System.Drawing.Color.Teal;
            this.btnKhamMoi.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKhamMoi.Location = new System.Drawing.Point(361, 1);
            this.btnKhamMoi.Name = "btnKhamMoi";
            this.btnKhamMoi.Size = new System.Drawing.Size(430, 82);
            this.btnKhamMoi.TabIndex = 9;
            this.btnKhamMoi.Text = "LẤY SỐ";
            this.btnKhamMoi.UseVisualStyleBackColor = false;
            this.btnKhamMoi.Visible = false;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.lbKhamMoi);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(150, 463);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1041, 74);
            this.panel8.TabIndex = 21;
            // 
            // lbKhamMoi
            // 
            this.lbKhamMoi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbKhamMoi.Font = new System.Drawing.Font("Tahoma", 38F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKhamMoi.ForeColor = System.Drawing.Color.Green;
            this.lbKhamMoi.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbKhamMoi.Location = new System.Drawing.Point(0, 0);
            this.lbKhamMoi.Margin = new System.Windows.Forms.Padding(300, 3, 3, 3);
            this.lbKhamMoi.Name = "lbKhamMoi";
            this.lbKhamMoi.Size = new System.Drawing.Size(1041, 74);
            this.lbKhamMoi.TabIndex = 5;
            this.lbKhamMoi.Text = "Lấy số với Bệnh nhân khám mới";
            this.lbKhamMoi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbKhamMoi.Visible = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(2, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1356, 723);
            this.tabControl1.TabIndex = 0;
            // 
            // lbCom
            // 
            this.lbCom.AutoSize = true;
            this.lbCom.Dock = System.Windows.Forms.DockStyle.Right;
            this.lbCom.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCom.Location = new System.Drawing.Point(1339, 3);
            this.lbCom.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbCom.Name = "lbCom";
            this.lbCom.Size = new System.Drawing.Size(0, 33);
            this.lbCom.TabIndex = 5;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 733);
            this.Controls.Add(this.tabControl1);
            this.Name = "MainForm";
            this.Text = "KIOS";
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMaBN;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbTheUutien;
        private System.Windows.Forms.Button btnDangKy;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbThongbao;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbLoi;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnKhamMoi;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label lbKhamMoi;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label lbCom;
    }
}