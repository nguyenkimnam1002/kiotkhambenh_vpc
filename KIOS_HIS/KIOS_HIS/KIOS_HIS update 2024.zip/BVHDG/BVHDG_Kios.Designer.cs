﻿using System.Drawing;

namespace L1_Mini
{
    partial class BVHDG_Kios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lbCom = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMaBN = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.lbTheUutien = new System.Windows.Forms.Label();
            this.btnDangKy = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbThongbao = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lbLoi = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnDichvu = new System.Windows.Forms.Button();
            this.buttonLaysoUT = new System.Windows.Forms.Button();
            this.btnKhamMoi = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lbKhamMoi = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblDSDV_notify = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.cboLOAIDV = new System.Windows.Forms.ComboBox();
            this.txtMADV = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTENDV = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lblDSTVT_notify = new System.Windows.Forms.Label();
            this.btnTKTVT = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.cboLoaiTVT = new System.Windows.Forms.ComboBox();
            this.txtMATVT = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label14 = new System.Windows.Forms.Label();
            this.cboKIOS = new System.Windows.Forms.ComboBox();
            this.cboDinhdanhKIOS = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cboKHOA = new System.Windows.Forms.ComboBox();
            this.btnViewMap = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.lbTenBN = new System.Windows.Forms.Label();
            this.rTBThongTinThuoc = new System.Windows.Forms.RichTextBox();
            this.rTBThongTinCLS = new System.Windows.Forms.RichTextBox();
            this.rTBThongTinKham = new System.Windows.Forms.RichTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblTKBA_notify = new System.Windows.Forms.Label();
            this.btnTKIEMBA = new System.Windows.Forms.Button();
            this.txtMABA = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(1, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1360, 740);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 50);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1352, 686);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "   ĐĂNG KÝ KHÁM  ";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 1150F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.lbCom, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel5, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel6, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel7, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.panel8, 1, 7);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1346, 680);
            this.tableLayoutPanel1.TabIndex = 9;
            // 
            // lbCom
            // 
            this.lbCom.AutoSize = true;
            this.lbCom.Dock = System.Windows.Forms.DockStyle.Right;
            this.lbCom.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCom.Location = new System.Drawing.Point(1343, 3);
            this.lbCom.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbCom.Name = "lbCom";
            this.lbCom.Size = new System.Drawing.Size(0, 30);
            this.lbCom.TabIndex = 5;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtMaBN);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(101, 166);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1144, 84);
            this.panel1.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 33F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(296, 53);
            this.label1.TabIndex = 13;
            this.label1.Text = "Mã tìm kiếm";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtMaBN
            // 
            this.txtMaBN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMaBN.Font = new System.Drawing.Font("Tahoma", 46F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaBN.Location = new System.Drawing.Point(361, 1);
            this.txtMaBN.Margin = new System.Windows.Forms.Padding(3, 10, 300, 3);
            this.txtMaBN.MaxLength = 500;
            this.txtMaBN.Name = "txtMaBN";
            this.txtMaBN.Size = new System.Drawing.Size(783, 100);
            this.txtMaBN.TabIndex = 0;
            this.txtMaBN.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMaBN_KeyDown);
            this.txtMaBN.Leave += new System.EventHandler(this.txtMaBN_Leave);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txtHoTen);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(101, 256);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1144, 84);
            this.panel2.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 33F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(352, 53);
            this.label2.TabIndex = 14;
            this.label2.Text = "Tên Bệnh nhân";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtHoTen
            // 
            this.txtHoTen.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtHoTen.Font = new System.Drawing.Font("Tahoma", 46F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHoTen.Location = new System.Drawing.Point(361, 1);
            this.txtHoTen.Margin = new System.Windows.Forms.Padding(3, 10, 300, 3);
            this.txtHoTen.MaxLength = 500;
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(783, 100);
            this.txtHoTen.TabIndex = 2;
            this.txtHoTen.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtHoTen_KeyDown);
            this.txtHoTen.Leave += new System.EventHandler(this.txtHoTen_Leave);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.btnRefresh);
            this.panel3.Controls.Add(this.lbTheUutien);
            this.panel3.Controls.Add(this.btnDangKy);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(101, 346);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1144, 84);
            this.panel3.TabIndex = 16;
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.CadetBlue;
            this.btnRefresh.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.Location = new System.Drawing.Point(843, 1);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(298, 82);
            this.btnRefresh.TabIndex = 6;
            this.btnRefresh.Text = "Xóa";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // lbTheUutien
            // 
            this.lbTheUutien.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTheUutien.ForeColor = System.Drawing.Color.Green;
            this.lbTheUutien.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbTheUutien.Location = new System.Drawing.Point(68, 26);
            this.lbTheUutien.Margin = new System.Windows.Forms.Padding(3);
            this.lbTheUutien.Name = "lbTheUutien";
            this.lbTheUutien.Size = new System.Drawing.Size(222, 40);
            this.lbTheUutien.TabIndex = 5;
            this.lbTheUutien.Text = "Dùng thẻ ưu tiên!";
            this.lbTheUutien.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnDangKy
            // 
            this.btnDangKy.BackColor = System.Drawing.Color.CadetBlue;
            this.btnDangKy.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangKy.Location = new System.Drawing.Point(360, 1);
            this.btnDangKy.Name = "btnDangKy";
            this.btnDangKy.Size = new System.Drawing.Size(430, 82);
            this.btnDangKy.TabIndex = 3;
            this.btnDangKy.Text = "ĐĂNG KÝ KHÁM";
            this.btnDangKy.UseVisualStyleBackColor = false;
            this.btnDangKy.Visible = false;
            this.btnDangKy.Click += new System.EventHandler(this.btnDangKy_Click_1);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.Controls.Add(this.lbThongbao);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(101, 36);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1144, 74);
            this.panel4.TabIndex = 17;
            // 
            // lbThongbao
            // 
            this.lbThongbao.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbThongbao.Font = new System.Drawing.Font("Tahoma", 38F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbThongbao.ForeColor = System.Drawing.Color.Green;
            this.lbThongbao.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbThongbao.Location = new System.Drawing.Point(0, 0);
            this.lbThongbao.Margin = new System.Windows.Forms.Padding(300, 3, 3, 3);
            this.lbThongbao.Name = "lbThongbao";
            this.lbThongbao.Size = new System.Drawing.Size(1144, 74);
            this.lbThongbao.TabIndex = 4;
            this.lbThongbao.Text = "Vui lòng nhập/quẹt Mã BN để lấy số thứ tự";
            this.lbThongbao.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.Controls.Add(this.lbLoi);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(101, 116);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1144, 44);
            this.panel5.TabIndex = 18;
            // 
            // lbLoi
            // 
            this.lbLoi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbLoi.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLoi.ForeColor = System.Drawing.Color.Red;
            this.lbLoi.Location = new System.Drawing.Point(0, 0);
            this.lbLoi.Margin = new System.Windows.Forms.Padding(0);
            this.lbLoi.Name = "lbLoi";
            this.lbLoi.Size = new System.Drawing.Size(1144, 44);
            this.lbLoi.TabIndex = 3;
            this.lbLoi.Text = "Lỗi: Nhập sai mã Bệnh nhân!";
            this.lbLoi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Transparent;
            this.panel6.Controls.Add(this.label3);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(101, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1144, 27);
            this.panel6.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1144, 27);
            this.label3.TabIndex = 0;
            this.label3.Text = "|";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Visible = false;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Transparent;
            this.panel7.Controls.Add(this.btnDichvu);
            this.panel7.Controls.Add(this.buttonLaysoUT);
            this.panel7.Controls.Add(this.btnKhamMoi);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(101, 538);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1144, 84);
            this.panel7.TabIndex = 20;
            // 
            // btnDichvu
            // 
            this.btnDichvu.BackColor = System.Drawing.Color.Teal;
            this.btnDichvu.Font = new System.Drawing.Font("Tahoma", 26F, System.Drawing.FontStyle.Bold);
            this.btnDichvu.Location = new System.Drawing.Point(803, 0);
            this.btnDichvu.Name = "btnDichvu";
            this.btnDichvu.Size = new System.Drawing.Size(341, 82);
            this.btnDichvu.TabIndex = 11;
            this.btnDichvu.Text = "VÉ DỊCH VỤ";
            this.btnDichvu.UseVisualStyleBackColor = false;
            this.btnDichvu.Visible = false;
            this.btnDichvu.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonLaysoUT
            // 
            this.buttonLaysoUT.BackColor = System.Drawing.Color.Teal;
            this.buttonLaysoUT.Font = new System.Drawing.Font("Tahoma", 26F, System.Drawing.FontStyle.Bold);
            this.buttonLaysoUT.Location = new System.Drawing.Point(477, -1);
            this.buttonLaysoUT.Name = "buttonLaysoUT";
            this.buttonLaysoUT.Size = new System.Drawing.Size(341, 82);
            this.buttonLaysoUT.TabIndex = 10;
            this.buttonLaysoUT.Text = "LẤY SỐ ƯT";
            this.buttonLaysoUT.UseVisualStyleBackColor = false;
            this.buttonLaysoUT.Visible = false;
            this.buttonLaysoUT.Click += new System.EventHandler(this.buttonLaysoUT_Click);
            // 
            // btnKhamMoi
            // 
            this.btnKhamMoi.BackColor = System.Drawing.Color.Teal;
            this.btnKhamMoi.Font = new System.Drawing.Font("Tahoma", 26F, System.Drawing.FontStyle.Bold);
            this.btnKhamMoi.Location = new System.Drawing.Point(133, 2);
            this.btnKhamMoi.Name = "btnKhamMoi";
            this.btnKhamMoi.Size = new System.Drawing.Size(338, 82);
            this.btnKhamMoi.TabIndex = 9;
            this.btnKhamMoi.Text = "LẤY SỐ";
            this.btnKhamMoi.UseVisualStyleBackColor = false;
            this.btnKhamMoi.Visible = false;
            this.btnKhamMoi.Click += new System.EventHandler(this.btnKhamMoi_Click_1);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Transparent;
            this.panel8.Controls.Add(this.lbKhamMoi);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(101, 458);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1144, 74);
            this.panel8.TabIndex = 21;
            // 
            // lbKhamMoi
            // 
            this.lbKhamMoi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbKhamMoi.Font = new System.Drawing.Font("Tahoma", 38F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKhamMoi.ForeColor = System.Drawing.Color.Green;
            this.lbKhamMoi.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbKhamMoi.Location = new System.Drawing.Point(0, 0);
            this.lbKhamMoi.Margin = new System.Windows.Forms.Padding(300, 3, 3, 3);
            this.lbKhamMoi.Name = "lbKhamMoi";
            this.lbKhamMoi.Size = new System.Drawing.Size(1144, 74);
            this.lbKhamMoi.TabIndex = 5;
            this.lbKhamMoi.Text = "Lấy số với Bệnh nhân khám mới";
            this.lbKhamMoi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbKhamMoi.Visible = false;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage2.Controls.Add(this.lblDSDV_notify);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.cboLOAIDV);
            this.tabPage2.Controls.Add(this.txtMADV);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.txtTENDV);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 50);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1352, 686);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "  TRA CỨU DỊCH VỤ  ";
            // 
            // lblDSDV_notify
            // 
            this.lblDSDV_notify.AutoSize = true;
            this.lblDSDV_notify.Font = new System.Drawing.Font("Arial", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDSDV_notify.ForeColor = System.Drawing.Color.Red;
            this.lblDSDV_notify.Location = new System.Drawing.Point(570, 152);
            this.lblDSDV_notify.Name = "lblDSDV_notify";
            this.lblDSDV_notify.Size = new System.Drawing.Size(306, 32);
            this.lblDSDV_notify.TabIndex = 21;
            this.lblDSDV_notify.Text = "Không tìm thấy dữ liệu";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.AliceBlue;
            this.button1.Font = new System.Drawing.Font("Tahoma", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1156, 22);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(168, 116);
            this.button1.TabIndex = 20;
            this.button1.Text = "Tìm kiếm";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(569, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(181, 52);
            this.label6.TabIndex = 19;
            this.label6.Text = "Loại dịch vụ";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cboLOAIDV
            // 
            this.cboLOAIDV.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLOAIDV.Font = new System.Drawing.Font("Tahoma", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboLOAIDV.ForeColor = System.Drawing.Color.Blue;
            this.cboLOAIDV.FormattingEnabled = true;
            this.cboLOAIDV.Location = new System.Drawing.Point(783, 22);
            this.cboLOAIDV.Name = "cboLOAIDV";
            this.cboLOAIDV.Size = new System.Drawing.Size(300, 61);
            this.cboLOAIDV.TabIndex = 18;
            this.cboLOAIDV.SelectedIndexChanged += new System.EventHandler(this.cboLOAIDV_SelectedIndexChanged);
            // 
            // txtMADV
            // 
            this.txtMADV.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMADV.Font = new System.Drawing.Font("Tahoma", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMADV.Location = new System.Drawing.Point(230, 22);
            this.txtMADV.Margin = new System.Windows.Forms.Padding(3, 10, 300, 3);
            this.txtMADV.MaxLength = 500;
            this.txtMADV.Name = "txtMADV";
            this.txtMADV.Size = new System.Drawing.Size(312, 60);
            this.txtMADV.TabIndex = 17;
            this.txtMADV.TextChanged += new System.EventHandler(this.txtMADV_TextChanged);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(-10, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(196, 52);
            this.label5.TabIndex = 16;
            this.label5.Text = "Tên dịch vụ";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtTENDV
            // 
            this.txtTENDV.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTENDV.Font = new System.Drawing.Font("Tahoma", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTENDV.Location = new System.Drawing.Point(230, 85);
            this.txtTENDV.Margin = new System.Windows.Forms.Padding(3, 10, 300, 3);
            this.txtTENDV.MaxLength = 500;
            this.txtTENDV.Name = "txtTENDV";
            this.txtTENDV.Size = new System.Drawing.Size(312, 60);
            this.txtTENDV.TabIndex = 15;
            this.txtTENDV.TextChanged += new System.EventHandler(this.txtTENDV_TextChanged);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(-6, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(183, 50);
            this.label4.TabIndex = 14;
            this.label4.Text = "Mã dịch vụ";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeight = 40;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.Location = new System.Drawing.Point(28, 194);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1296, 465);
            this.dataGridView1.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage3.Controls.Add(this.lblDSTVT_notify);
            this.tabPage3.Controls.Add(this.btnTKTVT);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.cboLoaiTVT);
            this.tabPage3.Controls.Add(this.txtMATVT);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.dataGridView2);
            this.tabPage3.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.Location = new System.Drawing.Point(4, 50);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1352, 686);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "  TRA CỨU THUỐC - VẬT TƯ  ";
            // 
            // lblDSTVT_notify
            // 
            this.lblDSTVT_notify.AutoSize = true;
            this.lblDSTVT_notify.Font = new System.Drawing.Font("Arial", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDSTVT_notify.ForeColor = System.Drawing.Color.Red;
            this.lblDSTVT_notify.Location = new System.Drawing.Point(569, 148);
            this.lblDSTVT_notify.Name = "lblDSTVT_notify";
            this.lblDSTVT_notify.Size = new System.Drawing.Size(306, 32);
            this.lblDSTVT_notify.TabIndex = 30;
            this.lblDSTVT_notify.Text = "Không tìm thấy dữ liệu";
            // 
            // btnTKTVT
            // 
            this.btnTKTVT.BackColor = System.Drawing.Color.AliceBlue;
            this.btnTKTVT.Font = new System.Drawing.Font("Tahoma", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTKTVT.Location = new System.Drawing.Point(1109, 28);
            this.btnTKTVT.Name = "btnTKTVT";
            this.btnTKTVT.Size = new System.Drawing.Size(180, 52);
            this.btnTKTVT.TabIndex = 29;
            this.btnTKTVT.Text = "Tìm kiếm";
            this.btnTKTVT.UseVisualStyleBackColor = false;
            this.btnTKTVT.Click += new System.EventHandler(this.btnTKTVT_Click);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(638, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 52);
            this.label8.TabIndex = 28;
            this.label8.Text = "Loại ";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cboLoaiTVT
            // 
            this.cboLoaiTVT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiTVT.Font = new System.Drawing.Font("Tahoma", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboLoaiTVT.FormattingEnabled = true;
            this.cboLoaiTVT.ItemHeight = 53;
            this.cboLoaiTVT.Items.AddRange(new object[] {
            "Tất cả",
            "Thuốc Vật tư",
            "Nhóm thuốc Vật tư"});
            this.cboLoaiTVT.Location = new System.Drawing.Point(774, 30);
            this.cboLoaiTVT.Name = "cboLoaiTVT";
            this.cboLoaiTVT.Size = new System.Drawing.Size(300, 61);
            this.cboLoaiTVT.TabIndex = 27;
            this.cboLoaiTVT.SelectedIndexChanged += new System.EventHandler(this.cboLoaiTVT_SelectedIndexChanged);
            // 
            // txtMATVT
            // 
            this.txtMATVT.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMATVT.Font = new System.Drawing.Font("Tahoma", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMATVT.Location = new System.Drawing.Point(321, 32);
            this.txtMATVT.Margin = new System.Windows.Forms.Padding(3, 10, 300, 3);
            this.txtMATVT.MaxLength = 500;
            this.txtMATVT.Name = "txtMATVT";
            this.txtMATVT.Size = new System.Drawing.Size(302, 60);
            this.txtMATVT.TabIndex = 26;
            this.txtMATVT.TextChanged += new System.EventHandler(this.txtMATVT_TextChanged);
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(35, 33);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(267, 50);
            this.label10.TabIndex = 23;
            this.label10.Text = "Mã / Tên thuốc";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToOrderColumns = true;
            this.dataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView2.ColumnHeadersHeight = 40;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView2.EnableHeadersVisualStyles = false;
            this.dataGridView2.Location = new System.Drawing.Point(28, 195);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(1296, 464);
            this.dataGridView2.TabIndex = 22;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.cboKIOS);
            this.tabPage4.Controls.Add(this.cboDinhdanhKIOS);
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.cboKHOA);
            this.tabPage4.Controls.Add(this.btnViewMap);
            this.tabPage4.Controls.Add(this.pictureBox1);
            this.tabPage4.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage4.Location = new System.Drawing.Point(4, 50);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1352, 686);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "  TRA CỨU BẢN ĐỒ  ";
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(115, 89);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(181, 52);
            this.label14.TabIndex = 35;
            this.label14.Text = "Chọn kios";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cboKIOS
            // 
            this.cboKIOS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboKIOS.Font = new System.Drawing.Font("Tahoma", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboKIOS.ForeColor = System.Drawing.Color.Blue;
            this.cboKIOS.FormattingEnabled = true;
            this.cboKIOS.Location = new System.Drawing.Point(327, 91);
            this.cboKIOS.Name = "cboKIOS";
            this.cboKIOS.Size = new System.Drawing.Size(401, 61);
            this.cboKIOS.TabIndex = 34;
            // 
            // cboDinhdanhKIOS
            // 
            this.cboDinhdanhKIOS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDinhdanhKIOS.Font = new System.Drawing.Font("Tahoma", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboDinhdanhKIOS.ForeColor = System.Drawing.Color.Blue;
            this.cboDinhdanhKIOS.FormattingEnabled = true;
            this.cboDinhdanhKIOS.Location = new System.Drawing.Point(327, 100);
            this.cboDinhdanhKIOS.Name = "cboDinhdanhKIOS";
            this.cboDinhdanhKIOS.Size = new System.Drawing.Size(808, 61);
            this.cboDinhdanhKIOS.TabIndex = 33;
            this.cboDinhdanhKIOS.Visible = false;
            this.cboDinhdanhKIOS.SelectedIndexChanged += new System.EventHandler(this.cboDinhdanhKIOS_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(115, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(181, 52);
            this.label7.TabIndex = 32;
            this.label7.Text = "Chọn khoa";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cboKHOA
            // 
            this.cboKHOA.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboKHOA.Font = new System.Drawing.Font("Tahoma", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboKHOA.ForeColor = System.Drawing.Color.Blue;
            this.cboKHOA.FormattingEnabled = true;
            this.cboKHOA.Location = new System.Drawing.Point(327, 24);
            this.cboKHOA.Name = "cboKHOA";
            this.cboKHOA.Size = new System.Drawing.Size(401, 61);
            this.cboKHOA.TabIndex = 31;
            // 
            // btnViewMap
            // 
            this.btnViewMap.BackColor = System.Drawing.Color.AliceBlue;
            this.btnViewMap.Font = new System.Drawing.Font("Tahoma", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewMap.Location = new System.Drawing.Point(780, 24);
            this.btnViewMap.Name = "btnViewMap";
            this.btnViewMap.Size = new System.Drawing.Size(355, 53);
            this.btnViewMap.TabIndex = 30;
            this.btnViewMap.Text = "Chỉ đường";
            this.btnViewMap.UseVisualStyleBackColor = false;
            this.btnViewMap.Click += new System.EventHandler(this.btnViewMap_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(44, 156);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1268, 512);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage5.Controls.Add(this.lbTenBN);
            this.tabPage5.Controls.Add(this.rTBThongTinThuoc);
            this.tabPage5.Controls.Add(this.rTBThongTinCLS);
            this.tabPage5.Controls.Add(this.rTBThongTinKham);
            this.tabPage5.Controls.Add(this.label13);
            this.tabPage5.Controls.Add(this.label12);
            this.tabPage5.Controls.Add(this.label11);
            this.tabPage5.Controls.Add(this.lblTKBA_notify);
            this.tabPage5.Controls.Add(this.btnTKIEMBA);
            this.tabPage5.Controls.Add(this.txtMABA);
            this.tabPage5.Controls.Add(this.label9);
            this.tabPage5.Location = new System.Drawing.Point(4, 50);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1352, 686);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "TRA CỨU LSK";
            // 
            // lbTenBN
            // 
            this.lbTenBN.Font = new System.Drawing.Font("Tahoma", 25F, System.Drawing.FontStyle.Bold);
            this.lbTenBN.ForeColor = System.Drawing.Color.Green;
            this.lbTenBN.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbTenBN.Location = new System.Drawing.Point(266, 103);
            this.lbTenBN.Margin = new System.Windows.Forms.Padding(3);
            this.lbTenBN.Name = "lbTenBN";
            this.lbTenBN.Size = new System.Drawing.Size(1064, 56);
            this.lbTenBN.TabIndex = 43;
            this.lbTenBN.Text = "Tên BN";
            this.lbTenBN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rTBThongTinThuoc
            // 
            this.rTBThongTinThuoc.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rTBThongTinThuoc.Location = new System.Drawing.Point(271, 517);
            this.rTBThongTinThuoc.Name = "rTBThongTinThuoc";
            this.rTBThongTinThuoc.ReadOnly = true;
            this.rTBThongTinThuoc.Size = new System.Drawing.Size(1073, 159);
            this.rTBThongTinThuoc.TabIndex = 42;
            this.rTBThongTinThuoc.Text = "";
            // 
            // rTBThongTinCLS
            // 
            this.rTBThongTinCLS.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rTBThongTinCLS.Location = new System.Drawing.Point(271, 345);
            this.rTBThongTinCLS.Name = "rTBThongTinCLS";
            this.rTBThongTinCLS.ReadOnly = true;
            this.rTBThongTinCLS.Size = new System.Drawing.Size(1073, 166);
            this.rTBThongTinCLS.TabIndex = 41;
            this.rTBThongTinCLS.Text = "";
            // 
            // rTBThongTinKham
            // 
            this.rTBThongTinKham.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rTBThongTinKham.Location = new System.Drawing.Point(272, 207);
            this.rTBThongTinKham.Name = "rTBThongTinKham";
            this.rTBThongTinKham.ReadOnly = true;
            this.rTBThongTinKham.Size = new System.Drawing.Size(1073, 132);
            this.rTBThongTinKham.TabIndex = 39;
            this.rTBThongTinKham.Text = "";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(-1, 495);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(200, 50);
            this.label13.TabIndex = 36;
            this.label13.Text = "Thông tin thuốc: ";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(-1, 331);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(181, 50);
            this.label12.TabIndex = 35;
            this.label12.Text = "Thông tin CLS:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(-1, 187);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(200, 50);
            this.label11.TabIndex = 34;
            this.label11.Text = "Thông tin khám: ";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTKBA_notify
            // 
            this.lblTKBA_notify.AutoSize = true;
            this.lblTKBA_notify.Font = new System.Drawing.Font("Arial", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTKBA_notify.ForeColor = System.Drawing.Color.Red;
            this.lblTKBA_notify.Location = new System.Drawing.Point(624, 157);
            this.lblTKBA_notify.Name = "lblTKBA_notify";
            this.lblTKBA_notify.Size = new System.Drawing.Size(306, 32);
            this.lblTKBA_notify.TabIndex = 33;
            this.lblTKBA_notify.Text = "Không tìm thấy dữ liệu";
            // 
            // btnTKIEMBA
            // 
            this.btnTKIEMBA.BackColor = System.Drawing.Color.AliceBlue;
            this.btnTKIEMBA.Font = new System.Drawing.Font("Tahoma", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTKIEMBA.Location = new System.Drawing.Point(763, 45);
            this.btnTKIEMBA.Name = "btnTKIEMBA";
            this.btnTKIEMBA.Size = new System.Drawing.Size(180, 52);
            this.btnTKIEMBA.TabIndex = 32;
            this.btnTKIEMBA.Text = "Tìm kiếm";
            this.btnTKIEMBA.UseVisualStyleBackColor = false;
            this.btnTKIEMBA.Click += new System.EventHandler(this.btnTKIEMBA_Click);
            // 
            // txtMABA
            // 
            this.txtMABA.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMABA.Font = new System.Drawing.Font("Tahoma", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMABA.Location = new System.Drawing.Point(272, 37);
            this.txtMABA.Margin = new System.Windows.Forms.Padding(3, 10, 300, 3);
            this.txtMABA.MaxLength = 500;
            this.txtMABA.Name = "txtMABA";
            this.txtMABA.Size = new System.Drawing.Size(428, 60);
            this.txtMABA.TabIndex = 31;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(9, 38);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(235, 50);
            this.label9.TabIndex = 30;
            this.label9.Text = "Mã BA";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BVHDG_Kios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1362, 741);
            this.Controls.Add(this.tabControl1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BVHDG_Kios";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CẤP SỐ BVĐAKHOA";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.BVHDG_Kios_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.CapSo_FormClosed);
            this.Load += new System.EventHandler(this.BVHDG_Kios_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BVDAKHOA_Kios_KeyDown);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.ResumeLayout(false);

        }
        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lbCom;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMaBN;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbTheUutien;
        private System.Windows.Forms.Button btnDangKy;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbThongbao;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbLoi;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label lbKhamMoi;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cboLOAIDV;
        private System.Windows.Forms.TextBox txtMADV;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTENDV;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblDSDV_notify;
        private System.Windows.Forms.Label lblDSTVT_notify;
        private System.Windows.Forms.Button btnTKTVT;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cboLoaiTVT;
        private System.Windows.Forms.TextBox txtMATVT;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnViewMap;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cboKHOA;
        private System.Windows.Forms.ComboBox cboDinhdanhKIOS;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button buttonLaysoUT;
        private System.Windows.Forms.Button btnDichvu;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button btnTKIEMBA;
        private System.Windows.Forms.TextBox txtMABA;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblTKBA_notify;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RichTextBox rTBThongTinKham;
        private System.Windows.Forms.RichTextBox rTBThongTinThuoc;
        private System.Windows.Forms.RichTextBox rTBThongTinCLS;
        private System.Windows.Forms.Label lbTenBN;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cboKIOS;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnKhamMoi;
    }
}



