﻿namespace L1_Mini
{
    partial class Kios_DKHNM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Kios_DKHNM));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lbTheUutien = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMaBN = new System.Windows.Forms.TextBox();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.btnLaySo = new System.Windows.Forms.Button();
            this.btnDangKy = new System.Windows.Forms.Button();
            this.btnTimkiem = new System.Windows.Forms.Button();
            this.lbThongbao = new System.Windows.Forms.Label();
            this.lbCom = new System.Windows.Forms.Label();
            this.lbLoi = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 3F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 94F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 3F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbThongbao, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbCom, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbLoi, 1, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 370F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1354, 741);
            this.tableLayoutPanel1.TabIndex = 8;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(43, 224);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1266, 364);
            this.panel1.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 400F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.tableLayoutPanel2.Controls.Add(this.lbTheUutien, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label2, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.txtMaBN, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtHoTen, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label3, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.btnTimkiem, 2, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33148F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33704F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33148F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1266, 364);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // lbTheUutien
            // 
            this.lbTheUutien.AutoSize = true;
            this.lbTheUutien.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbTheUutien.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTheUutien.ForeColor = System.Drawing.Color.Green;
            this.lbTheUutien.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbTheUutien.Location = new System.Drawing.Point(3, 255);
            this.lbTheUutien.Margin = new System.Windows.Forms.Padding(3);
            this.lbTheUutien.Name = "lbTheUutien";
            this.lbTheUutien.Padding = new System.Windows.Forms.Padding(0, 35, 0, 0);
            this.lbTheUutien.Size = new System.Drawing.Size(394, 106);
            this.lbTheUutien.TabIndex = 5;
            this.lbTheUutien.Text = "Dùng thẻ ưu tiên!";
            this.lbTheUutien.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Tahoma", 33F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(394, 111);
            this.label2.TabIndex = 14;
            this.label2.Text = "Tên Bệnh nhân";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtMaBN
            // 
            this.txtMaBN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMaBN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtMaBN.Font = new System.Drawing.Font("Tahoma", 46F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaBN.Location = new System.Drawing.Point(403, 10);
            this.txtMaBN.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.txtMaBN.MaxLength = 500;
            this.txtMaBN.Name = "txtMaBN";
            this.txtMaBN.Size = new System.Drawing.Size(728, 82);
            this.txtMaBN.TabIndex = 1;
            this.txtMaBN.TextChanged += new System.EventHandler(this.txtMaBN_TextChanged);
            this.txtMaBN.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMaBN_KeyDown);
            this.txtMaBN.Leave += new System.EventHandler(this.txtMaBN_Leave);
            // 
            // txtHoTen
            // 
            this.txtHoTen.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtHoTen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtHoTen.Font = new System.Drawing.Font("Tahoma", 46F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHoTen.Location = new System.Drawing.Point(403, 151);
            this.txtHoTen.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.txtHoTen.MaxLength = 500;
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(728, 82);
            this.txtHoTen.TabIndex = 2;
            this.txtHoTen.TextChanged += new System.EventHandler(this.txtHoTen_TextChanged);
            this.txtHoTen.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtHoTen_KeyDown);
            this.txtHoTen.Leave += new System.EventHandler(this.txtHoTen_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Tahoma", 33F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(394, 111);
            this.label1.TabIndex = 13;
            this.label1.Text = "Mã tìm kiếm";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(403, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(647, 24);
            this.label3.TabIndex = 15;
            this.label3.Text = "( Tối đa 10 chữ số với mã Bệnh nhân, 15 chữ số với mã Bảo hiểm y tế )";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.67442F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.32558F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Controls.Add(this.btnLaySo, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.btnDangKy, 1, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(403, 255);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 106F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(735, 106);
            this.tableLayoutPanel3.TabIndex = 16;
            // 
            // btnLaySo
            // 
            this.btnLaySo.BackColor = System.Drawing.Color.CadetBlue;
            this.btnLaySo.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLaySo.Location = new System.Drawing.Point(3, 3);
            this.btnLaySo.Name = "btnLaySo";
            this.btnLaySo.Size = new System.Drawing.Size(234, 100);
            this.btnLaySo.TabIndex = 4;
            this.btnLaySo.Text = "LẤY SỐ";
            this.btnLaySo.UseVisualStyleBackColor = false;
            this.btnLaySo.Click += new System.EventHandler(this.btnLaySTT_Click_cu);
            // 
            // btnDangKy
            // 
            this.btnDangKy.BackColor = System.Drawing.Color.CadetBlue;
            this.btnDangKy.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangKy.Location = new System.Drawing.Point(243, 3);
            this.btnDangKy.Name = "btnDangKy";
            this.btnDangKy.Size = new System.Drawing.Size(423, 100);
            this.btnDangKy.TabIndex = 3;
            this.btnDangKy.Text = "ĐĂNG KÝ KHÁM";
            this.btnDangKy.UseVisualStyleBackColor = false;
            this.btnDangKy.Click += new System.EventHandler(this.btnDangKy_Click);
            // 
            // btnTimkiem
            // 
            this.btnTimkiem.BackColor = System.Drawing.Color.CadetBlue;
            this.btnTimkiem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTimkiem.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimkiem.Image = ((System.Drawing.Image)(resources.GetObject("btnTimkiem.Image")));
            this.btnTimkiem.Location = new System.Drawing.Point(1144, 9);
            this.btnTimkiem.Margin = new System.Windows.Forms.Padding(3, 9, 3, 18);
            this.btnTimkiem.Name = "btnTimkiem";
            this.btnTimkiem.Size = new System.Drawing.Size(119, 84);
            this.btnTimkiem.TabIndex = 17;
            this.btnTimkiem.UseVisualStyleBackColor = false;
            this.btnTimkiem.Click += new System.EventHandler(this.btnTimkiem_Click);
            // 
            // lbThongbao
            // 
            this.lbThongbao.AutoSize = true;
            this.lbThongbao.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbThongbao.Font = new System.Drawing.Font("Tahoma", 38F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbThongbao.ForeColor = System.Drawing.Color.Green;
            this.lbThongbao.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbThongbao.Location = new System.Drawing.Point(290, 19);
            this.lbThongbao.Margin = new System.Windows.Forms.Padding(250, 3, 3, 3);
            this.lbThongbao.Name = "lbThongbao";
            this.lbThongbao.Size = new System.Drawing.Size(1019, 154);
            this.lbThongbao.TabIndex = 4;
            this.lbThongbao.Text = "Vui lòng nhập/quẹt Mã Bệnh nhân để lấy số thứ tự";
            this.lbThongbao.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbCom
            // 
            this.lbCom.AutoSize = true;
            this.lbCom.Dock = System.Windows.Forms.DockStyle.Right;
            this.lbCom.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCom.Location = new System.Drawing.Point(1351, 3);
            this.lbCom.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbCom.Name = "lbCom";
            this.lbCom.Size = new System.Drawing.Size(0, 13);
            this.lbCom.TabIndex = 5;
            // 
            // lbLoi
            // 
            this.lbLoi.AutoSize = true;
            this.lbLoi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbLoi.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLoi.ForeColor = System.Drawing.Color.Red;
            this.lbLoi.Location = new System.Drawing.Point(40, 176);
            this.lbLoi.Margin = new System.Windows.Forms.Padding(0);
            this.lbLoi.Name = "lbLoi";
            this.lbLoi.Size = new System.Drawing.Size(1272, 45);
            this.lbLoi.TabIndex = 3;
            this.lbLoi.Text = "Lỗi: Nhập sai mã Bệnh nhân!";
            this.lbLoi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Kios_DKHNM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1354, 741);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Kios_DKHNM";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CẤP SỐ ĐK-HÀ NAM";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.Kios_DKHNM_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Kios_DKHNM_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.CapSo_FormClosed);
            this.Load += new System.EventHandler(this.Kios_DKHNM_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Kios_DKHNM_KeyDown);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        #endregion

        //private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbLoi;
        private System.Windows.Forms.Label lbThongbao;
        private System.Windows.Forms.TextBox txtMaBN;
        private System.Windows.Forms.Label lbTheUutien;
        private System.Windows.Forms.Label lbCom;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button btnDangKy;
        private System.Windows.Forms.Button btnLaySo;
        private System.Windows.Forms.Button btnTimkiem;
    }
}



